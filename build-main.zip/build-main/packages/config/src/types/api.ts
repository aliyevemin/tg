export type IntegrationResponse = {
  slug: string
  version: string
  has_build: boolean
}
